# Starter Seed for Auth0-Angular2 Quickstart Guides

This is a default app provided by https://github.com/angular/quickstart. It has basic configuration to start an angula2 application.

Install the npm packages described in the package.json and verify that it works:

```bash
npm install
npm start
```

The npm start command first compiles the application, then simultaneously re-compiles and runs the lite-server. Both the compiler and the server watch for file changes.

Shut it down manually with Ctrl-C.

You're ready to write your application.
